#read file
from operation import *         #importing from operation
def funtion_for_read():
    file=open('item.txt','r') 
    item_id=1         #openes the file items.txt in read mode
    my_Dict={}                      #Intializing a dictionary my_Dict                     

    for line in file:
     line=line.replace('\n','')
     my_Dict[item_id]=line.split(',')
     item_id=item_id+1

    file.close()
    return my_Dict 

