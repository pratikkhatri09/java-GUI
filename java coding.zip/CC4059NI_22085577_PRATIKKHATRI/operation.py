#operation file 

from read import*               
from datetime import datetime   

def function_for_returning():

    my_Dict=funtion_for_read()        
    items_purchased=[]             
    date_time = None  
    days_rented=0                  
    contact_Number=None            
    fine=0                     
    grand_Total=0                
    total_fine=0                

    print("\n")
    name=input("Enter your name: ")
    while True:
        try:
            contact_Number=int(input("Enter your contact number: "))
            if isinstance(contact_Number, str):   
                raise ValueError 
            else:
                break
        except ValueError:
            print("Invalid contact number !! Please provide a valid number. ")
            
    print("\n")
    print("--------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print("S.N. \t\t\t\tName of item \t\t\t\tbrand\t\t \t\tUnit Price\t \t\t\tQuantity")
    print("--------------------------------------------------------------------------------------------------------------------------------------------------------------")

    file= open(str(name)+str(contact_Number)+".txt","w")
    file=open("item.txt","r")
    sn=1
    for line in file:
        print(sn,"\t\t"+line.replace(",","\t\t"))
        sn=sn+1
    file.close()
    print("--------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print("\n")

    more=True
    while more:
        while True:
            try:
                id_Item= int(input("Provide the id of the item you want to return: "))
                
                if id_Item<=0 or id_Item>len(my_Dict):
                    raise ValueError
                else:
                    while True:
                        try:
                            quantity_item= int(input("Please provide the number of quantity of the item you want to reuturn: "))
                            
                            if quantity_item<=0 or quantity_item > 100: 
                                raise ValueError  
                            else:                                            
                                my_Dict[id_Item][3]= int (my_Dict[id_Item][3])+int(quantity_item)
                                file=open("item.txt","w")
                                for values in my_Dict.values():
                                    file.write(str(values[0])+","+str(values[1])+","+str(values[2])+","+str(values[3]))
                                    file.write("\n")
                                file.close()
                
                                brand_Name=my_Dict[id_Item][0]                          
                                quantity_selected= quantity_item                             
                                unit_price= my_Dict[id_Item][2]                          
                                price_selected= my_Dict[id_Item][2].replace("$",'')  
                                total_Price=int(price_selected)*int(quantity_selected)   
                                unit_priceInt=int(unit_price.replace("$",''))   
                            
                                while True:
                                    try:
                                        days_rented=int(input("Enter the number of days you rented: "))
                                        if days_rented<1:                             
                                            raise ValueError
                                        else:
                                            if days_rented<=5:                        
                                                fine=0
                                            elif days_rented%5!=0:                     
                                                fineday=(((int(days_rented//5)+1)*5)-5)*quantity_item
                                                fine=int((fineday/5))*int(unit_priceInt)  
                                            else:                                    
                                                fine=(days_rented-5)*int(unit_priceInt)
                                            total_fine=total_fine+fine
                                            items_purchased.append([brand_Name, quantity_selected, unit_price, total_Price,days_rented,fine,total_fine])#adds to the list
                            
                                            rent_exit= input("Enter 'E' to exit and 'C' to continue returning more items!").upper()
                                            
                                            if rent_exit=="C":
                                                print("\n")
                                                more=True
                                            else:
                                                more=False

                                            grand_Total=0
                                            if rent_exit=="Y":          
                                                more=True
                                            else:                           
                                                total=0
                                                for i in items_purchased:
                                                    total=total+int(i[3])
                                                grand_Total= total+total_fine
                                                date_time = datetime.now()        
                                            break
                                    except ValueError:
                                        print("Enter valid number of days.")  
                                        print("\n")
                            break    
                        except ValueError:
                            print("Invalid quantity!! Please enter a valid quantity.")
                            print("\n")
                break        
            except ValueError:
                print("Invalid ID!! Please enter a valid ID. ") 

    return name, contact_Number, items_purchased, date_time, grand_Total, fine,total_fine     


def function_for_rent():
    my_Dict=funtion_for_read()     
    items_purchased=[]         
    date_time = None  

    name=input("Please enter your name: ")

    while True:
        try:
            contact_Number=int(input("Enter your contact number: "))
            if isinstance(contact_Number, str)or contact_Number<=0:   
                raise ValueError 
            else:
                break
        except ValueError:                          
            print("Please enter a valid number")
            
    print("\n")
    print("--------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print("S.N. \t\t\tName of item\t \t\t\t\tbrand\t\t \t\tUnit Price\t \t\t\tQuantity")
    print("--------------------------------------------------------------------------------------------------------------------------------------------------------------")

    file=open("item.txt","r")
    sn=1
    for line in file:
        print(sn,"\t\t\t"+line.replace(",","\t\t\t"))
        sn=sn+1
    file.close()
    print("--------------------------------------------------------------------------------------------------------------------------------------------------------------")
    print("\n")
    more=True
    while more:
        while True:
            try:
                id_Item= int(input("Provide the S.N of the item that you want to rent:"))
                if (id_Item<=0 or id_Item>len(my_Dict)):     
                    raise ValueError        
                else:
                    while True:
                        try:
                            quantity_item= int(input("provide the quantity of the item that you want to rent: "))

                            quantity_selected= my_Dict[id_Item][3]

                            if quantity_item<=0 or quantity_item > int(quantity_selected): 
                                raise ValueError
                            else:
                                my_Dict[id_Item][3]= int (my_Dict[id_Item][3])-int(quantity_item)
                                file=open("item.txt","w")

                                for values in my_Dict.values():
                                    file.write(str(values[0])+","+str(values[1])+","+str(values[2])+","+str(values[3]))
                                    file.write("\n")

                                file.close()

                                rent_exit= input("Enter 'E' to exit and 'C' to continue renting more items!").upper()
                                
                                if rent_exit=="C":
                                    more=True
                                else:
                                    more=False

                                
                                brand_Name=my_Dict[id_Item][0]                          
                                quantity_selected= quantity_item                             
                                unit_price= my_Dict[id_Item][2]                         
                                price_selected= my_Dict[id_Item][2].replace("$",'')  
                                total_Price=int(price_selected)*int(quantity_selected)  
                                items_purchased.append([brand_Name, quantity_selected, unit_price, total_Price]) 
                                print("\n")

                                grand_Total=0
                                if rent_exit=="Y":      
                                    more=True
                                else:                      
                                    total=0
                                    for i in items_purchased:
                                        total=total+int(i[3])
                                    grand_Total= total
                                    date_time = datetime.now()       
                            break   
                          
                        except ValueError:         
                            print("Please enter a valid quantity!")
                break 

            except ValueError:          
                print("Invalid ID!! please enter valid id. ")
       
    return name, contact_Number, items_purchased, date_time, grand_Total    

        
    
